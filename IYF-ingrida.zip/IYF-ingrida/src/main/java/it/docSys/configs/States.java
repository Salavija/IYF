package it.docSys.configs;

public enum States {
    PATEIKTAS, PRIIMTAS, ATMESTAS
}
