self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "39a5e672d587ac54e1af",
    "url": "/static/js/main.39a5e672.chunk.js"
  },
  {
    "revision": "66482f55bf581b4a0f26",
    "url": "/static/js/1.66482f55.chunk.js"
  },
  {
    "revision": "39a5e672d587ac54e1af",
    "url": "/static/css/main.925ea31e.chunk.css"
  },
  {
    "revision": "41fd76437be25ba09c5761a2e3b3524b",
    "url": "/index.html"
  }
];