package it.docSys.model;

public enum States {
    PATEIKTAS, PRIIMTAS, ATMESTAS
}
